

__BEGIN_SYS

namespace Scheduling_Criteria
{
    class Prioridade
    {
        //friend class EPOS::Thread;

    public:
        enum {
	        MAIN   = 0,
	        HIGH   = 1,
	        NORMAL = (unsigned(1) << (sizeof(int) * 8 - 1)) - 4,
	        LOW    = (unsigned(1) << (sizeof(int) * 8 - 1)) - 3,
	        IDLE   = (unsigned(1) << (sizeof(int) * 8 - 1)) - 2
	    };

        //static const bool timed = false;
        //static const bool dynamic = false;
        //static const bool preemptive = true;

    public:
        Prioridade(int p = NORMAL): _prioridade(p) {}

        operator const volatile int() const volatile { return _prioridade; }

        //void update() {}
        //unsigned int queue() const { return 0; }

    protected:
        volatile int _prioridade;
    };
}

template <typename T>
class Scheduler: public Scheduling_List<T>
{
private:
    typedef Scheduling_List<T> Base;

public:
    //typedef typename T::Criterion Criterion;
    //typedef Scheduling_List<T, Criterion> Queue;
    //typedef typename Queue::Element Element;

public:
    Scheduler() {}

    unsigned int schedulables() { return Base::size(); }
};

__END_SYS