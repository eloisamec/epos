#include <thread.h>

#ifndef __task_h
#define __task_h

#include <utility/malloc.h>
#include <address_space.h>
#include <segment.h>

__BEGIN_SYS

class Task
{
    friend class System;
    friend class Thread;

private:
    typedef CPU::Log_Addr Log_Addr;
    typedef CPU::Phy_Addr Phy_Addr;
    typedef CPU::Context Context;
    typedef class Queue<Thread> Queue;

protected:
    Task(Address_Space * addressSpace, const Segment * codeSegment, const Segment * dataSegment, Log_Addr code, Log_Addr data)
    : _addressSpace(addressSpace),_codeSegment(codeSegment), _dataSegment(dataSegment), _code(code), _data(data) {}

public:
    Task(const Segment & codeSegment, const Segment & dataSegment);
    ~Task();

    Address_Space * address_space() const { return _addressSpace; }
    const Segment * code_segment() const { return _codeSegment; }
    const Segment * data_segment() const { return _dataSegment; }
    Log_Addr code() const { return _code; }
    Log_Addr data() const { return _data; }

    static const Task * self() { return Thread::self()->task(); }

private:
    void activate() const { _addressSpace->activate(); }
    static void init();

private:
    Address_Space * _addressSpace;
    const Segment * _codeSegment;
    const Segment * _dataSegment;
    Log_Addr _code;
    Log_Addr _data;
    Queue _threads;

    static Task * _master;
};

__END_SYS

#endif
