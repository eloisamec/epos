// EPOS Address_Space Abstraction Declarations

#ifndef __address_space_h
#define __address_space_h

#include <mmu.h>
#include <segment.h>

__BEGIN_SYS
__BEGIN_STUB
class Address_Space
{
private:
    Log_Addr * mensagem = reinterpret_cast<Log_Addr *>(TRANSFER_SPACE);
    Agent * agent = new (SYSTEM) Agent();
public:
    Address_Space()
    {
        int size = 1;
        size += sizeof(ADDRESS_SPACE_NEW_ID_1);
        size += sizeof(unsigned int);
        void*[] m = {size, ADDRESS_SPACE_NEW_ID_1, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    Address_Space(MMU::Page_Directory * pd)
    {
        int size = 1;
        size += sizeof(ADDRESS_SPACE_NEW_ID_2);
        size += sizeof(unsigned int);
        size += sizeof(MMU::Page_Directory);
        void*[] m = {size, ADDRESS_SPACE_NEW_ID_1, &this, pd};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    ~Address_Space()
    {
        int size = 1;
        size += sizeof(ADDRESS_SPACE_DESTRUCTOR_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ADDRESS_SPACE_DESTRUCTOR_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    Log_Addr attach(const Segment & seg)
    {
        int size = 1;
        size += sizeof(ADDRESS_SPACE_ATTACH_ID_1);
        size += sizeof(unsigned int);
        size += sizeof(Segment);
        void*[] m = {size, ADDRESS_SPACE_ATTACH_ID_1, &this, seg};
        memcpy(mensagem, m, size);
        agent.read_message();
        Log_Addr log_addr = static_cast<Log_Addr> mensagem[1];
        return log_addr;
    }

    Log_Addr attach(const Segment & seg, Log_Addr addr)
    {
        int size = 1;
        size += sizeof(ADDRESS_SPACE_ATTACH_ID_2);
        size += sizeof(unsigned int);
        size += sizeof(Segment);
        size += sizeof(Log_Addr);
        void*[] m = {size, ADDRESS_SPACE_ATTACH_ID_2, &this, seg, addr};
        memcpy(mensagem, m, size);
        agent.read_message();
        Log_Addr log_addr = static_cast<Log_Addr> mensagem[1];
        return log_addr;
    }

    void detach(const Segment & seg)
    {
        int size = 1;
        size += sizeof(ADDRESS_SPACE_DETACH_ID);
        size += sizeof(unsigned int);
        size += sizeof(Segment);
        void*[] m = {size, ADDRESS_SPACE_DETACH_ID_1, &this, seg};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    Phy_Addr physical(Log_Addr address)
    {
        nt size = 1;
        size += sizeof(ADDRESS_SPACE_PHYSICAL_ID);
        size += sizeof(unsigned int);
        size += sizeof(Log_Addr);
        void*[] m = {size, ADDRESS_SPACE_PHYSICAL_ID, &this, address};
        memcpy(mensagem, m, size);
        agent.read_message();
        Phy_Addr physical = static_cast<Phy_Addr> mensagem[1];
        return physical;
    }
};
__END_STUB
__BEGIN_IMP
class Address_Space: private MMU::Directory
{
    friend class Task;

private:
    typedef CPU::Phy_Addr Phy_Addr;
    typedef CPU::Log_Addr Log_Addr;

    using MMU::Directory::activate;
    using MMU::Directory::pd;

public:
    Address_Space();
    Address_Space(MMU::Page_Directory * pd);
    ~Address_Space();

    Log_Addr attach(const Segment & seg);
    Log_Addr attach(const Segment & seg, Log_Addr addr);
    void detach(const Segment & seg);

    Phy_Addr physical(Log_Addr address);
};

__END_SYS

#endif