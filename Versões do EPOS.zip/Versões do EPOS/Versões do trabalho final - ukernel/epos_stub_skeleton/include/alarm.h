// EPOS Alarm Abstraction Declarations

#ifndef __alarm_h
#define __alarm_h

#include <utility/queue.h>
#include <utility/handler.h>
#include <tsc.h>
#include <rtc.h>
#include <timer.h>
#include <semaphore.h>

__BEGIN_SYS
__BEGIN_STUB
class Alarm
{
private:
    Log_Addr * mensagem = reinterpret_cast<Log_Addr *>(TRANSFER_SPACE); //= TRANSFER_SPACE
    Agent * agent = new (SYSTEM) Agent();
public:
    Alarm(const Microsecond & time, Handler * handler, int times = 1)
    {
        int size = 1;
        size += sizeof(ALARM_NEW_ID);
        size += sizeof(unsigned int);
        size += sizeof(Microsecond);
        size += sizeof(Handler);
        size += sizeof(int);
        void*[] m = {size, ALARM_NEW_ID, &this, time, handler, times};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    ~Alarm()
    {
        int size = 1;
        size += sizeof(ALARM_DESTRUCTOR_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_DESTRUCTOR_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();

    }

    Hertz frequency()
    {
        int size = 1;
        size += sizeof(ALARM_FREQUENCY_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_FREQUENCY_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
        Hertz hertz = static_cast<Hertz> mensagem[1];
        return hertz;
    }

    static void delay(const Microsecond & time)
    {
        int size = 1;
        size += sizeof(ALARM_DELAY_ID);
        size += sizeof(Microsecond);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_FREQUENCY_ID, time, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

private:
    static void init()
    {
        int size = 1;
        size += sizeof(ALARM_INIT_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_INIT_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    static Microsecond period()
    {
        int size = 1;
        size += sizeof(ALARM_PERIOD_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_PERIOD_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
        Microsecond ms = static_cast<Microsecond> mensagem[1];
        return ms;
    }

    static Ticks ticks()
    {
        int size = 1;
        size += sizeof(ALARM_TICKS_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_TICKS_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
        Ticks ticks = static_cast<Ticks> mensagem[1];
        return ticks;
    }

    static void lock()
    {
        int size = 1;
        size += sizeof(ALARM_LOCK_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_LOCK_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
    }

    static void unlock()
    {
        int size = 1;
        size += sizeof(ALARM_UNLOCK_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, ALARM_UNLOCK_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
    }
};
__END_STUB
__BEGIN_IMP
class Alarm
{
    friend class System;

private:
    typedef TSC::Hertz Hertz;
    typedef Timer::Tick Tick;  

    typedef Relative_Queue<Alarm, Tick> Queue;

public:
    typedef RTC::Microsecond Microsecond;
    
    // Infinite times (for alarms)
    enum { INFINITE = RTC::INFINITE };
    
public:
    Alarm(const Microsecond & time, Handler * handler, int times = 1);
    ~Alarm();

    static Hertz frequency() { return _timer->frequency(); }

    static void delay(const Microsecond & time);

private:
    static void init();

    static Microsecond period() {
        return 1000000 / frequency();
    }

    static Tick ticks(const Microsecond & time) {
        return (time + period() / 2) / period();
    }

    static void lock() { Thread::lock(); }
    static void unlock() { Thread::unlock(); }

    static void handler();

private:
    Tick _ticks;
    Handler * _handler;
    int _times; 
    Queue::Element _link;

    static Alarm_Timer * _timer;
    static volatile Tick _elapsed;
    static Queue _request;
};


class Delay
{
private:
    typedef RTC::Microsecond Microsecond;

public:
    Delay(const Microsecond & time): _time(time)  { Alarm::delay(_time); }

private:
    Microsecond _time;
};
__END_IMP
__END_SYS

#endif