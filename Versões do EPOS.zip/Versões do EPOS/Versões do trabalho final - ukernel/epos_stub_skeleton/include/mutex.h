// EPOS Mutex Abstraction Declarations

#ifndef __mutex_h
#define __mutex_h

#include <utility/handler.h>
#include <synchronizer.h>

__BEGIN_SYS

__BEGIN_STUB
class Mutex
{
private:
	Log_Addr * mensagem = reinterpret_cast<Log_Addr *>(TRANSFER_SPACE); //= TRANSFER_SPACE
	Agent * agent = new (SYSTEM) Agent();
public:
	Mutex()
	{
		int size = 1;
		size += sizeof(MUTEX_NEW_ID);
		void*[] m = {size, MUTEX_NEW_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
	}
	void lock()
	{
		int size = 1;
		size += sizeof(MUTEX_LOCK_ID);
		void*[] m = {size, MUTEX_LOCK_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
	}
	void unlock()
	{
		int size = 1;
		size += sizeof(MUTEX_UNLOCK_ID);
		void*[] m = {size, MUTEX_UNLOCK_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
	}
	~Mutex()
	{
		int size = 1;
		size += sizeof(MUTEX_DESTRUCTOR_ID);
		void*[] m = {size, MUTEX_DESTRUCTOR_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
	}
};
__END_STUB
__BEGIN_IMP

class Mutex: protected Synchronizer_Common
{
public:
    Mutex();
    ~Mutex();

    void lock();
    void unlock();

private:
    volatile bool _locked;
};
__END_IMP


// An event handler that triggers a mutex (see handler.h)
class Mutex_Handler: public Handler
{
public:
    Mutex_Handler(Mutex * h) : _handler(h) {}
    ~Mutex_Handler() {}

    void operator()() { _handler->unlock(); }

private:
    Mutex * _handler;
};

__END_SYS

#endif
