// EPOS Memory Segment Abstraction Declarations

#ifndef __segment_h
#define __segment_h

#include <mmu.h>

__BEGIN_SYS
__BEGIN_STUB
class Segment
{
private:
	Log_Addr * mensagem = reinterpret_cast<Log_Addr *>(TRANSFER_SPACE);
	Agent * agent = new (SYSTEM) Agent();
public:
	Segment(unsigned int bytes, Flags flags = Flags::APP)
	{
		int size = 1;
        size += sizeof(SEGMENT_NEW_ID_1);
        size += sizeof(unsigned int);
        size += sizeof(unsigned int);
        size += sizeof(Flags);
        void*[] m = {size, SEGMENT_NEW_ID_1, &this, bytes, flags};
        memcpy(mensagem, m, size);
        agent.read_message();
	}

	Segment(Phy_Addr phy_addr, unsigned int bytes, Flags flags = Flags::APP)
	{
		int size = 1;
        size += sizeof(SEGMENT_NEW_ID_2);
        size += sizeof(Phy_Addr);
        size += sizeof(unsigned int);
        size += sizeof(unsigned int);
        size += sizeof(Flags);
        void*[] m = {size, SEGMENT_NEW_ID, &this, phy_addr, bytes, flags};
        memcpy(mensagem, m, size);
        agent.read_message();
	}

	~Segment()
	{
		int size = 1;
        size += sizeof(SEGMENT_DESTRUCTOR_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, SEGMENT_DESTRUCTOR_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
	}

	unsigned int size()
	{
		int size = 1;
        size += sizeof(SEGMENT_SIZE_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, SEGMENT_SIZE_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
        unsigned int size = static_cast<unsigned int> mensagem[1];
        return size;
	}

	Phy_Addr phy_address()
	{
		int size = 1;
        size += sizeof(SEGMENT_PHY_ADDRESS_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, SEGMENT_PHY_ADDRESS_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
        Phy_Addr phy_addr = static_cast<phy_addr> mensagem[1];
        return phy_addr;
	}

	int resize(int amount)
	{
		int size = 1;
        size += sizeof(SEGMENT_RESIZE_ID);
        size += sizeof(unsigned int);
        size += sizeof(int);
        void*[] m = {size, SEGMENT_RESIZE_ID, &this, amount};
        memcpy(mensagem, m, size);
        agent.read_message();
        int resize = static_cast<int> mensagem[1];
        return resize;
	}
};
__END_STUB
__BEGIN_IMP
class Segment: public MMU::Chunk
{
private:
    typedef MMU::Chunk Chunk;

public:
    typedef MMU::Flags Flags;
    typedef CPU::Phy_Addr Phy_Addr;

public:
    Segment(unsigned int bytes, Flags flags = Flags::APP);
    Segment(Phy_Addr phy_addr, unsigned int bytes, Flags flags = Flags::APP);
    ~Segment();

    unsigned int size() const;
    Phy_Addr phy_address() const;
    int resize(int amount);
};
__END_IMP
__END_SYS

#endif