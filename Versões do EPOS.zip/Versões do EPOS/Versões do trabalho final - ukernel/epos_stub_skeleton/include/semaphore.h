// EPOS Semaphore Abstraction Declarations

#ifndef __semaphore_h
#define __semaphore_h

#include <utility/handler.h>
#include <synchronizer.h>

__BEGIN_SYS

__BEGIN_STUB
class Semaphore
{
private:
	Log_Addr * mensagem = reinterpret_cast<Log_Addr *>(TRANSFER_SPACE); //= TRANSFER_SPACE
	Agent * agent = new (SYSTEM) Agent();
public:
	Semaphore(int v = 1)
	{
		int size = 1;
		size += sizeof(SEMAPHORE_NEW_ID);
		size += sizeof(int);
		void*[] m = {size, SEMAPHORE_NEW_ID, v, &this};
        memcpy(mensagem, m, size);
        agent.read_message();
	}
	void p()
	{
		int size = 1;
		size += sizeof(SEMAPHORE_P_ID);
		void*[] m = {size, SEMAPHORE_P_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();	
	}
	void v()
	{
		int size = 1;
		size += sizeof(SEMAPHORE_V_ID);
		void*[] m = {size, SEMAPHORE_V_ID, &this};
        memcpy(mensagem, m, size);
        agent.read_message();	
	}
	~Semaphore()
	{
		size = 1;
        size += sizeof(SEMAPHORE_DESTRUCTOR_ID);
        size += sizeof(unsigned int);
        void*[] m = {size, SEMAPHORE_DESTRUCTOR_ID, &this);
        memcpy(mensagem, m, size);
        agent.read_message();   
	}
};
__END_STUB
__BEGIN_IMP

class Semaphore: protected Synchronizer_Common
{
public:
    Semaphore(int v = 1);
    ~Semaphore();

    void p();
    void v();

private:
    volatile int _value;
};

END_IMP


// An event handler that triggers a semaphore (see handler.h)
class Semaphore_Handler: public Handler
{
public:
    Semaphore_Handler(Semaphore * h) : _handler(h) {}
    ~Semaphore_Handler() {}

    void operator()() { _handler->v(); }

private:
    Semaphore * _handler;
};

__END_SYS

#endif
