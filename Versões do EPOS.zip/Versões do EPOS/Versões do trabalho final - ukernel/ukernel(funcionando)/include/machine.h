// EPOS Machine Mediator Common Package

#ifndef __machine_h
#define __machine_h

#include <system/config.h>

__BEGIN_SYS

class Machine_Common
{
protected:
    Machine_Common() {}
};

__END_SYS

#ifdef __MACH_H
#include __MACH_H
#endif

#endif
